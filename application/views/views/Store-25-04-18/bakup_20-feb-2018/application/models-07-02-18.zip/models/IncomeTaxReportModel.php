<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class IncomeTaxReportModel extends CI_Model {

	

}

/* End of file IncomeTaxReportModel.php */
/* Location: ./application/models/IncomeTaxReportModel.php */