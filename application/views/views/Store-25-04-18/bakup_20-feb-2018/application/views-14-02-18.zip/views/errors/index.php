<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>

<h1>آپکو اس آپشن کے حقوق حاصل نہیں ہیں.</h1>

</body>
</html>
