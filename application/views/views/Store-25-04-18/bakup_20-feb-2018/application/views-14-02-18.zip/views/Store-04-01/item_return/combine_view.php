 <?php $this->load->view('Store/direct_issue/DirectIssueSlip')?>
 <div style="page-break-after: always;">
 	
 </div>
 <?php $this->load->view('Store/stockslip/StockVoucher')?>