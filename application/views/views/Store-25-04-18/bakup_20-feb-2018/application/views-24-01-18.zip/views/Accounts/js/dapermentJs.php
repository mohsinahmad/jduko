<script src="<?php echo base_url()."assets/";?>urdutextbox.js"></script>
<script type="text/javascript">
// var sectionsCount = 0;
//  $("table").on('click','.cl' ,function() {

//    var count = 0;
//    $('.acc').select2("destroy");        
//    var $tr = $(this).closest('#addnew');
//    var $clone = $tr.clone(true)
//         .find('input[type=number]').prop("disabled",false).end()
//         .find('input[type=number]').val('').end()
//         .find('input[type=number]').val('').end()
//         .find('textarea').val('').end();
//     sectionsCount++;
//     $clone.find(':input').each(function(){

//         //set id to store the updated section number
//         var newId = this.id + sectionsCount;
//         //alert(this.id);
//         //update for label
//         $(this).prev().attr('for', newId);

//         //update id
//         this.id = newId;
        
//       //   alert('#'+newId);
//       //    $( '#'+newId ).focus(function(evt) {
//       //   alert(evt);
//       // MakeTextBoxUrduEnabled(newId);
// // });

//     }).end()

//    var $cloned = $tr.after($clone);
//                $cloned.find("textarea[data-test]").each(function(){
//             //alert(evt);
//             var testdata = $(this).attr('id');
            
//             $('#' + testdata).on('focus',function () {
//               console.log(testdata);
//                 MakeTextBoxUrduEnabled(testdata);
//             });
            
//             //alert(testdata);
//         });
//    $('.acc').select2({
//         placeholder: "Select a state",
//         allowClear: true
//    });
//    $clone.find('.acc').select2('val', '');

// });



</script>